package com.qawaemi.list

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Product(val id: Long, val brand: String, val category: String, val model: String, val description: String, val hp: String, val price: Double)

class ProductDb(ctx: Context) : SQLiteOpenHelper(ctx, "qawaemi.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, brand TEXT, category TEXT, model TEXT, description TEXT, hp TEXT, price REAL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun search(q: String): List<Product> {
        val out = mutableListOf<Product>(); val c = readableDatabase.query("products", null,
            "model LIKE ? OR description LIKE ? OR brand LIKE ? OR category LIKE ? OR hp LIKE ?",
            arrayOf("%$q%","%$q%","%$q%","%$q%","%$q%"), null,null,"model COLLATE NOCASE", "100")
        c.use { while(it.moveToNext()) out += Product(it.getLong(0),it.getString(1)?:(""),it.getString(2)?:(""),it.getString(3)?:(""),it.getString(4)?:(""),it.getString(5)?:(""),it.getDouble(6)) }
        return out
    }
    fun insert(p: Product) { writableDatabase.insert("products", null, ContentValues().apply { put("brand",p.brand);put("category",p.category);put("model",p.model);put("description",p.description);put("hp",p.hp);put("price",p.price) }) }
    fun count(): Int { val c=readableDatabase.rawQuery("SELECT COUNT(*) FROM products",null); c.use{it.moveToFirst();return it.getInt(0)} }
}
