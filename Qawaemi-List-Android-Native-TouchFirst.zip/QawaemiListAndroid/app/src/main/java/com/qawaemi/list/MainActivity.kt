package com.qawaemi.list

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("qawaemi_secure", MODE_PRIVATE) }
    private val alias = "qawaemi_list_master_key"
    private lateinit var db: ProductDb
    private lateinit var list: ListView
    private lateinit var search: EditText
    private lateinit var discount: EditText
    private val items = mutableListOf<Product>()
    private val adapter by lazy { ProductAdapter() }
    private val importCode = 701

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db=ProductDb(this); if(hasPassword()) showLock() else showFirstRun() }
    private fun hasPassword() = prefs.contains("password_blob")
    private fun showFirstRun(){ AlertDialog.Builder(this).setTitle("مرحبًا بك في قوائمي ليست").setMessage("التطبيق يبدأ بدون منتجات. يمكنك استيراد قائمة الأسعار الخاصة بك. هل تريد إنشاء كلمة مرور؟").setPositiveButton("إنشاء كلمة مرور"){_,_->createPasswordDialog()}.setNegativeButton("المتابعة بدون كلمة مرور"){_,_->showNativeHome()}.setCancelable(false).show() }
    private fun createPasswordDialog(){ val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;padding=24}; val p=EditText(this).apply{hint="كلمة المرور";inputType=129}; val c=EditText(this).apply{hint="تأكيد كلمة المرور";inputType=129};box.addView(p);box.addView(c);AlertDialog.Builder(this).setTitle("إنشاء كلمة المرور").setView(box).setPositiveButton("حفظ"){_,_->if(p.text.length<4||p.text.toString()!=c.text.toString())toast("تأكد من كلمة المرور")else{savePassword(p.text.toString()); val recovery= prefs.getString("recovery_blob",null)?.let{decrypt(it)} ?: ""; AlertDialog.Builder(this).setTitle("مفتاح الاسترداد").setMessage("احتفظ بهذا المفتاح في مكان آمن:

$recovery").setPositiveButton("حفظت المفتاح"){_,_->showNativeHome()}.setCancelable(false).show()}}.setNegativeButton("إلغاء",null).show() }

    private fun key(): SecretKey {
        val ks=java.security.KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
        (ks.getKey(alias,null) as? SecretKey)?.let{return it}
        val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return kg.generateKey()
    }
    private fun encrypt(text:String):String { val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());return Base64.encodeToString(c.iv,0)+":"+Base64.encodeToString(c.doFinal(text.toByteArray()),0) }
    private fun decrypt(blob:String):String?=try{val p=blob.split(":",limit=2);val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,Base64.decode(p[0],0)));String(c.doFinal(Base64.decode(p[1],0)))}catch(_:Exception){null}
    private fun hash(p:String,s:String)=MessageDigest.getInstance("SHA-256").digest((s+p).toByteArray()).joinToString(""){"%02x".format(it)}
    private fun savePassword(p:String){val recovery=Base64.encodeToString(ByteArray(12).also{SecureRandom().nextBytes(it)},Base64.NO_WRAP).replace("=","");prefs.edit().putString("recovery_blob",encrypt(recovery)).apply();val salt=ByteArray(16).also{SecureRandom().nextBytes(it)};val s=Base64.encodeToString(salt,0);prefs.edit().putString("password_blob",encrypt("$s:${hash(p,s)}")).apply()}
    private fun verify(p:String):Boolean{val b=prefs.getString("password_blob",null)?:return false;val v=decrypt(b)?.split(":",limit=2)?:return false;return v.size==2&&hash(p,v[0])==v[1]}
    private fun showLock(){setContentView(R.layout.activity_lock);findViewById<TextView>(R.id.title).text="قوائمي ليست";findViewById<TextView>(R.id.subtitle).text="التطبيق مقفل. أدخل كلمة المرور.";val pass=findViewById<EditText>(R.id.password);findViewById<EditText>(R.id.confirm).isVisible=false;val a=findViewById<Button>(R.id.action);a.text="فتح التطبيق";a.setOnClickListener{if(verify(pass.text.toString()))showNativeHome()else toast("كلمة المرور غير صحيحة")};findViewById<Button>(R.id.recover).apply{isVisible=true;text="استرداد الدخول";setOnClickListener{showRecoveryDialog()}}}
    private fun showNativeHome(){setContentView(R.layout.activity_native);list=findViewById(R.id.products);search=findViewById(R.id.search);discount=findViewById(R.id.discount);list.adapter=adapter;search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){refresh(s?.toString()?:(""))};override fun afterTextChanged(e:Editable?) {}});findViewById<Button>(R.id.importBtn).setOnClickListener{pickCsv()};findViewById<Button>(R.id.backupBtn).setOnClickListener{backup()};findViewById<Button>(R.id.settingsBtn).setOnClickListener{settings()};findViewById<TextView>(R.id.resultCount).text="قاعدة البيانات: ${db.count()} منتج";refresh("")}
    private fun refresh(q:String){items.clear();items.addAll(if(q.isBlank())emptyList() else db.search(q));adapter.notifyDataSetChanged();findViewById<TextView>(R.id.resultCount).text=if(q.isBlank())"اكتب اسم الموديل أو الوصف للبحث" else "النتائج: ${items.size}"}
    private inner class ProductAdapter:BaseAdapter(){override fun getCount()=items.size;override fun getItem(p:Int)=items[p];override fun getItemId(p:Int)=items[p].id;override fun getView(p:Int,v:View?,parent:ViewGroup):View{val x=layoutInflater.inflate(R.layout.item_product,parent,false);val i=items[p];x.findViewById<TextView>(R.id.model).text=i.model;x.findViewById<TextView>(R.id.details).text=listOf(i.brand,i.category,i.hp).filter{it.isNotBlank()}.joinToString(" • ");val d=discount.text.toString().toDoubleOrNull()?.coerceIn(0.0,100.0)?:0.0;val final=i.price*(1-d/100);x.findViewById<TextView>(R.id.price).text="السعر: ${fmt(i.price)}   |   بعد الخصم: ${fmt(final)}";return x}}
    private fun fmt(v:Double)=String.format("%,.2f",v).replace(".00","")
    private fun pickCsv(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="text/*";addCategory(Intent.CATEGORY_OPENABLE)},importCode)}
    override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data);if(req!=importCode||res!=RESULT_OK||data?.data==null)return;try{val text=contentResolver.openInputStream(data.data!!)?.bufferedReader()?.readText()?:"";importCsv(text);toast("تم الاستيراد. إجمالي المنتجات: ${db.count()}");showNativeHome()}catch(e:Exception){toast("تعذر استيراد الملف")}}
    private fun importCsv(t:String){t.lineSequence().drop(1).forEach{line->val p=line.split(",").map{it.trim().trim('"')};if(p.size>=2){db.insert(Product(0,p.getOrElse(0){""},p.getOrElse(1){""},p.getOrElse(2){""},p.getOrElse(3){""},p.getOrElse(4){""},p.getOrElse(5){"0"}.replace(" ","").toDoubleOrNull()?:0.0))}}}
    private fun backup(){val a=JSONArray();val c=db.readableDatabase.rawQuery("SELECT brand,category,model,description,hp,price FROM products",null);c.use{while(it.moveToNext())a.put(JSONObject().apply{put("brand",it.getString(0));put("category",it.getString(1));put("model",it.getString(2));put("description",it.getString(3));put("hp",it.getString(4));put("price",it.getDouble(5))})};val i=Intent(Intent.ACTION_SEND).apply{type="application/json";putExtra(Intent.EXTRA_TEXT,a.toString());putExtra(Intent.EXTRA_TITLE,"قوائمي ليست - نسخة احتياطية")};startActivity(Intent.createChooser(i,"مشاركة النسخة الاحتياطية"))}
    private fun settings(){val opts=arrayOf("تغيير كلمة المرور","إلغاء كلمة المرور","قفل التطبيق الآن");AlertDialog.Builder(this).setTitle("الأمان").setItems(opts){_,w->when(w){0->changePassword();1->cancelPassword();2->showLock()}}.show()}
    private fun changePassword(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;padding=24};val old=EditText(this).apply{hint="كلمة المرور الحالية";inputType=129};val n=EditText(this).apply{hint="كلمة المرور الجديدة";inputType=129};box.addView(old);box.addView(n);AlertDialog.Builder(this).setTitle("تغيير كلمة المرور").setView(box).setPositiveButton("حفظ"){_,_->if(!verify(old.text.toString()))toast("كلمة المرور الحالية غير صحيحة")else if(n.text.length<4)toast("كلمة المرور قصيرة")else{savePassword(n.text.toString());toast("تم تغيير كلمة المرور")}}.setNegativeButton("إلغاء",null).show()}
    private fun cancelPassword(){AlertDialog.Builder(this).setTitle("إلغاء كلمة المرور").setMessage("هل تريد إلغاء حماية التطبيق؟").setPositiveButton("إلغاء الحماية"){_,_->prefs.edit().remove("password_blob").apply();toast("تم إلغاء كلمة المرور")}.setNegativeButton("رجوع",null).show()}
    private fun showRecoveryDialog(){val input=EditText(this).apply{hint="مفتاح الاسترداد"};AlertDialog.Builder(this).setTitle("استرداد الدخول").setView(input).setPositiveButton("استرداد"){_,_->val saved=prefs.getString("recovery_blob",null)?.let{decrypt(it)};if(saved!=null&&saved==input.text.toString().trim()){prefs.edit().remove("password_blob").apply();showNativeHome()}else toast("مفتاح الاسترداد غير صحيح")}.setNegativeButton("إلغاء",null).show()}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
