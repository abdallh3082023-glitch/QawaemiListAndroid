# Qawaemi List release rules. WebView JavaScript bridge methods are intentionally public.
